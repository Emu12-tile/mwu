placement for adama univeristy
