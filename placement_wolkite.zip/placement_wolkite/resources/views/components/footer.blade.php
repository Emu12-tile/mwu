<div class="hk-footer-wrap container">
    <footer class="footer">
        <div class="row">
            <div class="col-md-6 col-sm-12">
                <p>Developed by<a href="#" class="text-dark" target="_blank">Yonas T.(Tel:+251953464171) ,Eyob B. & Emebet T. </a> © 2023</p>
            </div>
            {{-- <div class="col-md-6 col-sm-12">
                <p class="d-inline-block">Follow us</p>
                <a href="#" class="d-inline-block btn btn-icon btn-icon-only btn-indigo btn-icon-style-4"><span
                        class="btn-icon-wrap"><i class="fa fa-facebook"></i></span></a>
                <a href="#" class="d-inline-block btn btn-icon btn-icon-only btn-indigo btn-icon-style-4"><span
                        class="btn-icon-wrap"><i class="fa fa-twitter"></i></span></a>
                <a href="#" class="d-inline-block btn btn-icon btn-icon-only btn-indigo btn-icon-style-4"><span
                        class="btn-icon-wrap"><i class="fa fa-google-plus"></i></span></a>
            </div> --}}
        </div>
    </footer>
</div>
