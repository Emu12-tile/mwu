

<?php $__env->startSection('content'); ?>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <div class="container">

        <section class="hk-sec-wrapper mt-100">
            <div class="pull-right hk-sec-title">

                
            </div>
            <h5 class="hk-sec-title">የተወዳዳሪዎች 2ኛ ምርጫ ከ ቡድን መሪ በታች አጠቃላይ ውጤት </h5>

            <div class="row">
                <div class="col-sm">
                    <div class="table-wrap">

                        <table id="datable_6" class="table table-hover table-bordered w-100  pb-30">
                            <thead>
                                <tr>
                                    <th>ተ.ቁ</th>
                                    <th>ሙሉ ስም</th>
                                    

                                    <th>ለትምህርት ዝግጅት የሚሰጥ ነጥብ</th>
                                    <th>ለስራ ልምድ አገልግሎት የሚሰጥ ነጥብ</th>
                                    <th>ለውጤት ተኮር ምዘና</th>

                                    <th>አጠቃላይ ውጤት(100%)</th>
                                    <th>Action</th>
                                    <th>Submit</th>
                                    <th>pdf</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $j = 0;
                                ?>
                                <?php $__currentLoopData = $hrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $hr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($hr->form->choice2->position_type_id == 2): ?>
                                        <?php if($hr->status_hr == 0): ?>
                                            <tr>
                                                <td><?php echo e(++$j); ?></td>
                                                <td><?php echo e($hr->form->full_name); ?><p>(<?php echo e($hr->form->email); ?>)</p>
                                                </td>
                                                
                                                <td><?php echo e($hr->performance); ?></td>
                                                <td><?php echo e($hr->experience); ?></td>
                                                <td><?php echo e($hr->resultbased); ?></td>

                                                <td><?php echo e($hr->performance + $hr->experience + $hr->resultbased); ?>

                                                </td>
                                                <td> <a href="<?php echo e(route('secondhr.edit', $hr->id)); ?>" data-toggle="tooltip"
                                                        data-original-title="Edit"> <i class="icon-pencil"></i>
                                                    </a>


                                                </td>
                                                <td>


                                                    <div class="row">
                                                        <div class="col-sm">
                                                            <!-- Button trigger modal -->
                                                            <button type="button"
                                                                class="btn bg-green-dark-4 text-white btn-sm"
                                                                data-toggle="modal" data-target="#id1_<?php echo e($i); ?>">
                                                                Submit
                                                            </button>

                                                            <!-- Modal -->
                                                            <div class="modal fade" id="id1_<?php echo e($i); ?>"
                                                                tabindex="-1" role="dialog"
                                                                aria-labelledby="exampleModalCenter" aria-hidden="true">
                                                                <div class="modal-dialog modal-dialog-centered"
                                                                    role="document">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title">Submission</h5>
                                                                            <button type="button" class="close"
                                                                                data-dismiss="modal" aria-label="Close">
                                                                                <span aria-hidden="true">&times;</span>
                                                                            </button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <p>Are you sure do you want to submit
                                                                                <?php echo e($hr->form->full_name); ?>?

                                                                            </p>
                                                                        </div>
                                                                        <div class="modal-footer">
                                                                            <button type="button" class="btn btn-secondary"
                                                                                data-dismiss="modal">Close</button>
                                                                            <form
                                                                                action="<?php echo e(url('update-lowsecondhr/' . $hr->id)); ?>"
                                                                                method="POST"
                                                                                enctype="multipart/form-data">
                                                                                <?php echo csrf_field(); ?>

                                                                                <?php echo method_field('PUT'); ?>
                                                                                <button type="submit"
                                                                                    class="btn btn-green">
                                                                                    Yes</button>
                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>


                                                </td>
                                                <td>


                                                    <a href="" type="button"
                                                        class="btn btn-primary requestStat btn-sm" data-toggle="modal"
                                                        data-target="#id_<?php echo e($i); ?>"><i
                                                            class="ion ion-md-archive "></i>pdf
                                                    </a>

                                                    <div class="modal fade" id="id_<?php echo e($i); ?>" tabindex="-1"
                                                        role="dialog" aria-labelledby="exampleModalLongTitle"
                                                        aria-hidden="true">
                                                        <div class="modal-dialog modal-lg" role="document">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <div id="element-to-print">

                                                                        <h5 class="modal-title " id="exampleModalLongTitle">
                                                                            የተወዳዳሪው 2ኛ ምርጫ ከ ደረጃ በታች አጠቃላይ ውጤት
                                                                        </h5>
                                                                        <div class="modal-body">
                                                                            <table
                                                                                class="table table-hover table-bordered w-100  pb-30">
                                                                                <thead>
                                                                                    <tr>
                                                                                        <th></th>
                                                                                        <th></th>
                                                                                    </tr>
                                                                                </thead>
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td>ሙሉ ስም</td>
                                                                                        <td><?php echo e($hr->form->full_name); ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td>የትምህርት ደረጃና ዝግጅት</td>
                                                                                        <td>
                                                                                            <?php $__currentLoopData = $hr->form->education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                (<?php echo e($type->certificate); ?>,
                                                                                                <?php echo e($type->discipline1); ?>)
                                                                                                ,
                                                                                                (<?php echo e($type->diploma); ?>,
                                                                                                <?php echo e($type->discipline2); ?>)
                                                                                                ,
                                                                                                (<?php echo e($type->bsc); ?>,
                                                                                                <?php echo e($type->discipline3); ?>)
                                                                                                ,
                                                                                                (<?php echo e($type->msc); ?>,
                                                                                                <?php echo e($type->discipline4); ?>)
                                                                                                ,
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td>
                                                                                            ያለዎት የስራ ልምድ
                                                                                        </td>

                                                                                        <td>
                                                                                            <?php $__currentLoopData = $hr->form->experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $fo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                <p> ከ<?php echo e(Carbon::parse($fo->startingDate)->day); ?>/<?php echo e(Carbon::parse($fo->startingDate)->month); ?>/<?php echo e(Carbon::parse($fo->startingDate)->year); ?>

                                                                                                    እስከ
                                                                                                    <?php echo e(Carbon::parse($fo->endingDate)->day); ?>/<?php echo e(Carbon::parse($fo->endingDate)->month); ?>/<?php echo e(Carbon::parse($fo->endingDate)->year); ?>

                                                                                                    በ
                                                                                                    <?php echo e($fo->positionyouworked); ?>,
                                                                                                </p>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td>የሚወዳደሩበት የሥራ መደብ</td>
                                                                                        <td><?php echo e($hr->form->choice2->position); ?>

                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td>ለትምህርት ዝግጅት የሚሰጥ ነጥብ(40%)</td>
                                                                                        <td><?php echo e($hr->performance); ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td>ለስራ ልምድ አገልግሎት የሚሰጥ ነጥብ(30%)
                                                                                        </td>
                                                                                        <td> <?php echo e($hr->experience); ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td>ለውጤት ተኮር ምዘና(30%)</td>
                                                                                        <td><?php echo e($hr->resultbased); ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td>Remark</td>
                                                                                        <td><?php echo e($hr->remark); ?></td>
                                                                                    </tr>

                                                                                </tbody>
                                                                                <tfoot style="font-size: 20px;">
                                                                                    <tr>
                                                                                        <td>አጠቃላይ ውጤት(100%)</td>
                                                                                        <td><?php echo e($hr->performance + $hr->experience + $hr->resultbased); ?>

                                                                                        </td>
                                                                                    </tr>
                                                                                </tfoot>
                                                                            </table>
                                                                            <p>ከኮሚቴ ውጤት ሰጪ :<?php echo e($hr->user->name); ?></p>
                                                                        </div>
                                                                        <div class="footerpdf">
                                                                            <p>This pdf generated by
                                                                                <?php echo e(Auth::user()->name); ?> ©


                                                                                <?php
                                                                                $mytime = Carbon\Carbon::now()->tz('EAT');
                                                                                echo $mytime->toDateTimeString();
                                                                                ?>

                                                                        </div>
                                                                        <p class="mt-5 text-center">@copyright <a
                                                                                href="#" class="text-dark"
                                                                                target="_blank">AASTU(YEE)</a> © 2023</p>
                                                                        </p>






                                                                    </div>
                                                                    <button type="button" class="close"
                                                                        data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>



                                                                </div>

                                                            </div>
                                                        </div>

                                                    </div>
                                                </td>





                                            </tr>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>

                    </div>
                </div>
            </div>
        </section>





    </div>
    <div class="container">

        <section class="hk-sec-wrapper mt-100">
            <div class="pull-right hk-sec-title">


            </div>
            <h5 class="hk-sec-title">የተወዳዳሪዎች 2ኛ ምርጫ ከ ቡድን መሪ በታች አጠቃላይ ውጤት(100%) </h5>

            <div class="row">
                <div class="col-sm">
                    <div class="table-wrap">

                        <table id="datable_3" class="table table-hover table-bordered w-100  pb-30">
                            <thead>
                                <tr>
                                    <th>ተ.ቁ</th>
                                    <th>ሙሉ ስም</th>
                                    <th>ውጤት ሰጪ</th>

                                    <th>ለትምህርት ዝግጅት የሚሰጥ ነጥብ(40%)</th>
                                    <th>ለስራ ልምድ አገልግሎት የሚሰጥ ነጥብ(30%)</th>
                                    <th>ለውጤት ተኮር ምዘና(30%)</th>


                                    <th>አጠቃላይ ውጤት(100%)</th>
                                    <th>Submitted by</th>
                                    <th>Remark</th>


                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $j = 0;
                                ?>
                                <?php $__currentLoopData = $hrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $hr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($hr->form->choice2->position_type_id == 2): ?>
                                        <?php if($hr->status_hr == 1): ?>
                                            <tr>
                                                <td><?php echo e(++$j); ?></td>
                                                <td><?php echo e($hr->form->full_name); ?><p>(<?php echo e($hr->form->email); ?>)</p>
                                                </td>
                                                <td><?php echo e($hr->user->name); ?></td>
                                                <td><?php echo e($hr->performance); ?></td>
                                                <td><?php echo e($hr->experience); ?></td>
                                                <td><?php echo e($hr->resultbased); ?></td>


                                                <td><?php echo e($hr->performance + $hr->experience + $hr->resultbased); ?>

                                                </td>
                                                <td><?php echo e($hr->submit); ?></td>
                                                <td><?php echo e($hr->remark); ?></td>





                                            </tr>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                        
                    </div>
                </div>
            </div>
        </section>





    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.8.0/html2pdf.bundle.min.js"
        integrity="sha512-w3u9q/DeneCSwUDjhiMNibTRh/1i/gScBVp2imNVAMCt6cUHIw6xzhzcPFIaL3Q1EbI2l+nu17q2aLJJLo4ZYg=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>
        $(".requestStat").on("click", function() {
            // var element = document.getElementById("element-to-print")
            var element = $(this).closest("tr").find("#element-to-print")[0]
            html2pdf(element, {
                margin: 15,
                filename: 'Application form.pdf',
                image: {
                    type: 'jpeg',
                    quality: 0.98
                },
                html2canvas: {
                    scale: 3,
                    logging: true,
                    dpi: 192,
                    letterRendering: true
                },
                jsPDF: {
                    unit: 'mm',
                    format: 'a4',
                    orientation: 'portrait'
                }
            });
        });


        // $(".requestStat").on("click", function() {
        //     var cat_id = $(this).val();


        //     $.ajax({
        //         url: "pdf",

        //         method: 'GET',

        //         data: {
        //             "id": $(this).val(),
        //             "hr": $(this).attr("data-target")
        //         },
        //         success: function(data) {
        //             // console.log(data.hr);
        //             if (response.id) {
        //                 alert(" changed successfully");
        //             }
        //         },
        //         error: function(response) {}
        //     });

        // });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\placement_wolkite\resources\views/secondchoicelow/index.blade.php ENDPATH**/ ?>