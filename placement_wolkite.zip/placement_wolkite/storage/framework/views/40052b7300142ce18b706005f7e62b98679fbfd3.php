

<?php $__env->startSection('content'); ?>
    
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <div class="container">

        <section class="hk-sec-wrapper mt-100">
            <div class="pull-right hk-sec-title">
                <a href="<?php echo e(url('pos2')); ?>" class="btn btn-dark mr-25"> back </a>

            </div>
            <h5 class="hk-sec-title">ምርጫ 2 </h5>


            <div class="row" id="search_list">
                <div class="col-sm">
                    <div class="table-wrap">

                        <table id="datable_1" class="table table-hover  table-bordered w-100  pb-30">
                            <thead>
                                <tr>
                                    <th>ተቁ</th>
                                    <th>ሙሉ ስም</th>



                                    


                                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'hr')): ?>
                                        <th>SubmittedBy HR</th>
                                        <th>የሰው ኃይል ግምገማ</th>
                                    <?php endif; ?>
                                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                                        <th>action</th>
                                    <?php endif; ?>






                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <tr>
                                        <td><?php echo e(++$i); ?></td>
                                        <td>

                                            <button type="button" class="btn bg-blue-dark-4 text-white" data-toggle="modal"
                                                data-target="#id_<?php echo e($i); ?>">
                                                <?php echo e($form->full_name); ?></button>

                                        </td>

                                        

                                        


                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                                            <td>
                                                <form action="<?php echo e(route('secondhr.destroy', $form->id)); ?>" method="POST">

                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>

                                                    <button type="submit" class="btn btn-danger pd-10">
                                                        <a data-toggle="tooltip" data-original-title="delete"> <i
                                                                class=" icon-trash txt-danger"></i> </a>
                                                    </button>
                                                </form>
                                            </td>
                                        <?php endif; ?>
                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'hr')): ?>
                                            <td><?php echo e($form->submit); ?></td>
                                            <td><a class="btn  btn-dark " type="submit" id="btn-evaluate"
                                                    href="<?php echo e(route('addsecond', $form->id)); ?>"> evaluate</a>
                                            </td>
                                        <?php endif; ?>

                                        </td>
                                        <div class="modal fade" id="id_<?php echo e($i); ?>" tabindex="-1" role="dialog"
                                            aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLongTitle">
                                                            የተወዳዳሪው ሙሉ መረጃ</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form>




                                                            <div class="form-group row">
                                                                <label for="inputEmail3" class="col-sm-2 col-form-label">ሙሉ
                                                                    ስም</label>


                                                                <div class="col-sm-10">
                                                                    <input type="text" value="<?php echo e($form->full_name); ?>"
                                                                        name="full_name"class="form-control" id="inputname"
                                                                        placeholder=" firstName" readonly>
                                                                </div>

                                                            </div>
                                                            <div class="form-group row">
                                                                <label for="inputname"
                                                                    class="col-sm-2 col-form-label">ጾታ</label>
                                                                <div class="col-sm-10">
                                                                    <input type="text" value="<?php echo e($form->sex); ?>"
                                                                        name="sex"class="form-control " id="inputEmail3"
                                                                        readonly>
                                                                </div>
                                                            </div>



                                                            <div class="form-group row">
                                                                <label for="inputEmail3"
                                                                    class="col-sm-2 col-form-label">ኢሜይል</label>
                                                                <div class="col-sm-10">
                                                                    <input type="email" value="<?php echo e($form->email); ?>"
                                                                        name="email"class="form-control" id="inputname"
                                                                        placeholder="email" readonly>
                                                                </div>
                                                            </div>

                                                            <div class="form-group row">
                                                                <label for="inputEmail3" class="col-sm-2 col-form-label">ስልክ
                                                                    ቁጥር</label>
                                                                <div class="col-sm-10">
                                                                    <input type="text" value="<?php echo e($form->phone); ?>"
                                                                        name="phone"class="form-control" id="inputname"
                                                                        placeholder="phone" readonly>
                                                                </div>
                                                            </div>



                                                            <div class="form-group row">
                                                                <label for="inputname" class="col-sm-2 col-form-label">አሁን
                                                                    ያሉበት የስራ
                                                                    መደብ</label>
                                                                <div class="col-sm-10">
                                                                    <input type="text"
                                                                        value="<?php echo e($form->positionofnow); ?>"
                                                                        name="positionofnow"class="form-control "
                                                                        id="inputEmail3" readonly>
                                                                </div>
                                                            </div>
                                                            <div class="form-group row">
                                                                <label for="inputname"
                                                                    class="col-sm-2 col-form-label">ደረጃ</label>
                                                                <div class="col-sm-10">
                                                                    <input type="text" value="<?php echo e($form->level); ?>"
                                                                        name="level"class="form-control "
                                                                        id="inputEmail3" readonly>
                                                                </div>
                                                            </div>

                                                            <div class="form-group row">
                                                                <label for="fee"
                                                                    class="col-sm-2 col-form-label">ደምወዝ</label>
                                                                <div class="col-sm-10">
                                                                    <input type="text" value="<?php echo e($form->fee); ?>"
                                                                        name="fee"class="form-control "
                                                                        id="fee" readonly>
                                                                </div>
                                                            </div>
                                                            <h4 class="text-white text-center mt-50 mb-4"
                                                                style=" background-color:rgb(17,40,77)"> የትምህርት
                                                                ደረጃና የትምህርት ዝግጅት በቅድመ ተከተል</h4>
                                                            <div class="form-group  mb-100">

                                                                <label for="inputname"></label>


                                                                <?php $__currentLoopData = $form->education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                            </div>
                                                            <h4 class="text-white  text-center mt-3 mb-4 "
                                                                style=" background-color:rgb(17,40,77)"> የ
                                                                መወዳደርያ የስራ ክፍልና የስራ መደብ</h4>
                                                            <button
                                                                class="text-white text-left mt-3 mb-4 mr-150 text-left"style=" background-color:rgb(17,40,77)">
                                                                ምርጫ 1</button>
                                                            <div class="form-group row">
                                                                <label for="inputname" class="col-sm-2 col-form-label">የስራ
                                                                    ክፍሉ</label>
                                                                <div class="col-sm-10">
                                                                    <input type="text"
                                                                        value="<?php echo e($form->job_category->job_category); ?>"
                                                                        name="job_category"class="form-control "
                                                                        id="inputEmail3" readonly>
                                                                </div>
                                                            </div>
                                                            <div class="form-group row">
                                                                <label for="position" class="col-sm-2 col-form-label">የስራ
                                                                    መደብ</label>
                                                                <div class="col-sm-10">
                                                                    <input type="text"
                                                                        value="<?php echo e($form->position->position); ?>"
                                                                        name="position"class="form-control "
                                                                        id="position" readonly>
                                                                </div>
                                                            </div>

                                                            <button class="text-white text-left mt-3 mb-4 mr-150 text-left"
                                                                style=" background-color:rgb(17,40,77)"> ምርጫ 2</button>
                                                            <div class="form-group row">
                                                                <label for="inputname" class="col-sm-2 col-form-label">የስራ
                                                                    ክፍሉ</label>
                                                                <div class="col-sm-10">
                                                                    <input type="text"
                                                                        value="<?php echo e($form->jobcat2->job_category); ?>"
                                                                        name="job_category"class="form-control "
                                                                        id="job_category" readonly>
                                                                </div>
                                                            </div>
                                                            <div class="form-group row mb-25">
                                                                <label for="position" class="col-sm-2 col-form-label">የስራ
                                                                    መደብ</label>
                                                                <div class="col-sm-10">
                                                                    <input type="text"
                                                                        value="<?php echo e($form->choice2->position); ?>"
                                                                        name="position"class="form-control "
                                                                        id="position" readonly>
                                                                </div>
                                                            </div>
                                                            <div class="form-group  mt-100">
                                                                <label for="UniversityHiringEra">በዩኒቨርስቲዉ የቅጥር ዘመን
                                                                    በኢትዮጵያ
                                                                </label>

                                                                <input type="text"
                                                                    value="<?php echo e($form->UniversityHiringEra); ?>"
                                                                    name="UniversityHiringEra"class="form-control "
                                                                    id="UniversityHiringEra" readonly>

                                                            </div>
                                                            <div class="form-group  ">
                                                                <label for="UniversityHiringEra">በዩኒቨርስቲዉ አገልግሎት ዘመን
                                                                    (በዓመት,የስራ
                                                                    መደብ)
                                                                </label>

                                                                <input type="text"
                                                                    value="<?php echo e($form->servicPeriodAtUniversity); ?>"
                                                                    name="servicPeriodAtUniversity"class="form-control "
                                                                    id="servicPeriodAtUniversity" readonly>

                                                            </div>
                                                            <div class="form-group  ">
                                                                <label for="UniversityHiringEra">በሌላ መስርያ ቤት አገልግሎት
                                                                    ዘመን(በዓመት,የስራ
                                                                    መደብ)
                                                                </label>

                                                                <input type="text"
                                                                    value="<?php echo e($form->servicPeriodAtAnotherPlace); ?>"
                                                                    name="servicPeriodAtAnotherPlace"class="form-control "
                                                                    id="servicPeriodAtAnotherPlace" readonly>

                                                            </div>
                                                            <div class="form-group  ">
                                                                <label for="servicPeriodAtAnotherPlace">አገልግሎት ከዲፕሎማ
                                                                    በፊት(በዓመት,የስራ መደብ)
                                                                </label>

                                                                <input type="text"
                                                                    value="<?php echo e($form->serviceBeforeDiplo); ?>"
                                                                    name="serviceBeforeDiplo"class="form-control "
                                                                    id="serviceBeforeDiplo" readonly>

                                                            </div>
                                                            <div class="form-group ">
                                                                <label for="UniversityHiringEra"> አገልግሎት ከዲፕሎማ/ዲግሪ
                                                                    በኋላ(በዓመት, የስራ መደብ)
                                                                </label>

                                                                <input type="text"
                                                                    value="<?php echo e($form->serviceAfterDiplo); ?>"
                                                                    name="serviceAfterDiplo"class="form-control "
                                                                    id="serviceAfterDiplo" readonly>

                                                            </div>
                                                            <div class="form-group  ">
                                                                <label for="resultOfrecentPerform"> የሁለት ተከታታይ የቅርብ ጊዜ
                                                                    የሥራ
                                                                    አፈጻፀም አማካይ
                                                                    ውጤት(ከ100 በቁጥር)
                                                                </label>

                                                                <input type="text"
                                                                    value="<?php echo e($form->resultOfrecentPerform); ?>"
                                                                    name="resultOfrecentPerform"class="form-control "
                                                                    id="resultOfrecentPerform" readonly>

                                                            </div>
                                                            <div class="form-group  ">
                                                                <label for="DisciplineFlaw"> የዲስፕሊን ጉድለት
                                                                </label>

                                                                <input type="text" value="<?php echo e($form->DisciplineFlaw); ?>"
                                                                    name="DisciplineFlaw"class="form-control "
                                                                    id="DisciplineFlaw" readonly>

                                                            </div>
                                                            <div class="form-group  ">
                                                                <label for="MoreRoles">ተጨማሪ የሥራ ድርሻ
                                                                </label>

                                                                <input type="text" value="<?php echo e($form->MoreRoles); ?>"
                                                                    name="MoreRoles"class="form-control " id="MoreRoles"
                                                                    readonly>

                                                            </div>




                                                            <h4 class="text-white text-center mt-50 mb-4"
                                                                style=" background-color:rgb(17,40,77)">የስራ
                                                                ልምድ</h4>

                                                            <div class="form-group ">
                                                                <label for="inputEmail3"></label>


                                                                <?php $__currentLoopData = $form->experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <input type="text"
                                                                        value="[<?php echo e($ex->startingDate); ?> እስከ <?php echo e($ex->endingDate); ?> በ <?php echo e($ex->positionyouworked); ?>], "
                                                                        name="" class="form-control"
                                                                        id="inputname" placeholder="" readonly>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                            </div>

                                                        </form>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Close</button>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </tr>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                        


                    </div>
                </div>
            </div>
        </section>





    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\placement_wolkite\resources\views/secondchoice/secondchoice.blade.php ENDPATH**/ ?>