<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-xl-12">

                <section class="hk-sec-wrapper mt-100">



                    <h3 class="hk-sec-title text-white text-center color-wrap  "
                        style=" background-color:#456896; padding:10px;">ወልቂጤ ዩኒቨርሲቲ የሰራተኞች የስራ
                        ድልድል ማወዳደርያ ቅፅ</h3>
                    <div class="row">
                        <div class="col-sm">
                            <form action="<?php echo e(route('addposition', $form->id)); ?>"method="POST">

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>



                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="firstName"> የመጀምርያ ስም *</label>
                                        <input class="form-control" id="firstName" placeholder=" ስም"
                                            value="<?php echo e($form->firstName); ?>" type="text" name="firstName">

                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="middleName"> የአባት ስም*</label>
                                        <input class="form-control" id="middleName" placeholder=" ስም"
                                            value="<?php echo e($form->middleName); ?>" type="text" name="middleName">

                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="lastName"> የአያት ስም *</label>
                                        <input class="form-control" id="lastName" placeholder=" ስም"
                                            value="<?php echo e($form->lastName); ?>" type="text" name="lastName">

                                    </div>

                                    <div class="col-md-6 form-group">
                                        <label for="sex">ጾታ *</label>
                                        <input type="text" value="<?php echo e($form->sex); ?>"
                                            name="sex"class="form-control " id="inputEmail3">
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label class="control-label mb-10" for="email">ኢሜይል (የ አ.ሳ.ቴን ኢሜይል ብቻ
                                            ይጠቀሙ) *</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="icon-envelope-open"></i></span>
                                            </div>
                                            <input type="email" value="<?php echo e($form->email); ?>"
                                                name="email"class="form-control" id="inputname" placeholder="email">



                                        </div>

                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label class="control-label mb-10">ስልክ
                                            ቁጥር(09...) *</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="fa fa-phone"></i></span>
                                            </div>
                                            <input type="text" value="<?php echo e($form->phone); ?>"
                                                name="phone"class="form-control" id="inputname" placeholder="phone">
                                        </div>


                                    </div>
                                </div>



                                <div class="row">
                                    <div class="col-md-4 form-group">
                                        <label for="positionofnow">አሁን ያሉበት የስራ መደብ</label>
                                        <input type="text" value="<?php echo e($form->positionofnow); ?>"
                                            name="positionofnow"class="form-control " id="inputEmail3">
                                    </div>
                                    <div class="col-md-4 form-group">
                                        <label for="level_id">ደረጃ </label>
                                        <input type="text" value="<?php echo e($form->level ?? ''); ?>" name="level"
                                            class="form-control " id="inputEmail3">
                                    </div>
                                    <div class="col-md-4 form-group">
                                        <label for="fee">ደምወዝ (ETB)</label>
                                        <input type="text" value="<?php echo e($form->fee); ?>"
                                            name="fee"class="form-control " id="fee">
                                    </div>
                                </div>
                                <h3 class="text-white text-center mt-3 mb-4  "
                                    style=" background-color:#456896; margin:center">
                                    ያለዎት የትምህርት ዝግጅትና የትምህርት ደረጃ
                                </h3>
                                
                                <?php $__currentLoopData = $form->education ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $fo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row">
                                        <input type="hidden" value="<?php echo e($fo->id); ?> "
                                            name="addMoreFields[<?php echo e($i); ?>][id]"class="form-control "
                                            id="inputEmail3">
                                        <div class="col-md-4 form-group">
                                            <label for="level">Level</label>
                                            <input type="text" value="<?php echo e($fo->level); ?> "
                                                name="addMoreFields[<?php echo e($i); ?>][level]"class="form-control "
                                                id="inputEmail3">
                                        </div>

                                        <div class="col-md-4 form-group">
                                            <label for="discipline">የትምህርት ዝግጅት</label>
                                            <input type="text" value="<?php echo e($fo->discipline); ?>"
                                                name="addMoreFields[<?php echo e($i); ?>][discipline]"class="form-control "
                                                id="inputEmail3">
                                        </div>
                                        <div class="col-md-4 form-group">
                                            <label for="completion_date">completion_date</label>
                                            <input type="text" value="<?php echo e($fo->completion_date); ?>"
                                                name="addMoreFields[<?php echo e($i); ?>][completion_date]"class="form-control "
                                                id="inputEmail3">
                                        </div>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>











                                <h3 class="text-white text-center
                                        mt-3 mb-4 "
                                    style=" background-color:#456896; margin:center">
                                    አገልግሎት
                                </h3>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="UniversityHiringEra"> የቅጥር ዘመን በኢትዮጵያ
                                            አቆጣጠር</label>
                                        <input type="text" value="<?php echo e($form->UniversityHiringEra); ?>"
                                            name="UniversityHiringEra"class="form-control " id="UniversityHiringEra">

                                    </div>
                                    

                                    
                                    
                                    
                                    <div class="col-md-6 form-group">
                                        <label for="resultOfrecentPerform" class=""> የሁለት ተከታታይ የቅርብ ጊዜ የሥራ
                                            አፈጻፀም አማካይ
                                            ውጤት(ከ100 በቁጥር)</label>
                                        <input type="text" value="<?php echo e($form->resultOfrecentPerform); ?>"
                                            name="resultOfrecentPerform"class="form-control " id="resultOfrecentPerform">
                                    </div>

                                    <div class="col-md-6 form-group">
                                        <label for="DisciplineFlaw">የፋይል ጥራት</label>
                                        <input type="text" value="<?php echo e($form->DisciplineFlaw); ?>"
                                            name="DisciplineFlaw"class="form-control " id="DisciplineFlaw">
                                    </div>
                                    


                                </div>
                                <h3 class="text-white text-center mt-3 mb-4   "
                                    style=" background-color:#456896; margin:center nav">የስራ ልምድ(በኢትዮጵያ አቆጣጠር
                                    ብቻ)</h3>

                                <?php $__currentLoopData = $form->experiences ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $fo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row ">
                                        <input type="hidden" value="<?php echo e($fo->id); ?> "
                                            name="addMoreInputFields[<?php echo e($i); ?>][id]"class="form-control "
                                            id="inputEmail3">
                                        <div class="col-md-4 form-group">
                                            <label for="startingDate">የጀመሩበት ዓመት(ወር/ቀን/ዓመት)</label>
                                            <input type="date" value="<?php echo e($fo->startingDate); ?>"
                                                name="addMoreInputFields[<?php echo e($i); ?>][startingDate]"class="form-control "
                                                id="inputEmail3">
                                            <?php $__errorArgs = ['startingDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                        <div class="col-md-4 form-group">
                                            <label for="endingDate">ያበቃበት ዓመት(ወር/ቀን/ዓመት)</label>
                                            <input type="date" value="<?php echo e($fo->endingDate); ?>"
                                                name="addMoreInputFields[<?php echo e($i); ?>][endingDate]"class="form-control "
                                                id="inputEmail3">
                                        </div>
                                        <div class="col-md-4 form-group">
                                            <label for="positionyouworked">የስራ መደብ</label>
                                            <input type="text" value="<?php echo e($fo->positionyouworked); ?>"
                                                name="addMoreInputFields[<?php echo e($i); ?>][positionyouworked]"class="form-control "
                                                id="inputEmail3">
                                        </div>
                                        

                                        
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div id="myform">
                                    <div class="row">
                                        <div class="col-sm">

                                            <div class=" formgr row">

                                                <div class="col-md-3">

                                                    <label for="startingDate">የጀመሩበት ዓመት(ወር/ቀን/ዓመት)</label>
                                                    <input type="date" name="addFields[0][startingDate]"
                                                        value="<?php echo e(old('startingDate')); ?>"
                                                        class="form-control  <?php $__errorArgs = ['startingDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="startingDate" placeholder=" ">
                                                    <?php $__errorArgs = ['startingDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class=" error invalid-feedback">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                                <div class="col-md-3">
                                                    <label for="endingDate">ያበቃበት ቀን(ወር/ቀን/ዓመት) </label>
                                                    <input type="date" min="startingDate"
                                                        name="addFields[0][endingDate]" value="<?php echo e(old('endingDate')); ?>"
                                                        class="form-control  <?php $__errorArgs = ['endingDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="endingDate" placeholder=" endingDate">
                                                    <?php $__errorArgs = ['endingDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class=" error invalid-feedback">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="col-md-4">
                                                    <label for="positionyouworked">የስራ መደብ </label>
                                                    <input type="text" name="addFields[0][positionyouworked]"
                                                        value="<?php echo e(old('positionyouworked')); ?>"
                                                        class="form-control  <?php $__errorArgs = ['positionyouworked'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="positionyouworked" placeholder="የሰሩበት የስራ መደብ">
                                                    <?php $__errorArgs = ['positionyouworked'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class=" error invalid-feedback">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div>
                                                    <a href="javascript:void(0)"
                                                        class="btn color-wrap text-white bg-blue-dark-4  addRow mt-40 "
                                                        style=" border-radius:50%">+</a>
                                                </div>
                                            </div>

                                        </div>
                                    </div>


                                </div>





                                <h3 class="text-white text-center mt-3 mb-4 navigation "
                                    style=" background-color:#456896; margin:center"> የሚወዳደሩበት የስራ ክፍልና
                                    የስራ
                                    መደብ
                                </h3>
                                <button class="text-white text-left mt-3 mb-4 mr-150" style=" background-color:#456896">
                                    ምርጫ 1</button>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for=""> የስራ ክፍሉ</label>


                                        <select class="form-control custom-select d-block w-100 dynamic"
                                            name="job_category_id" id="job_category_id">
                                            <option value="">Choose</option>
                                            <?php $__currentLoopData = $job_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($col->id); ?>"
                                                    <?php echo e($form->job_category_id == $col->id ? 'selected' : ''); ?>>
                                                    <?php echo e($col->job_category); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                    </div>
                                    <div class="col-md-6 form-group">

                                        <label for="position_id"> የስራ መደብ</label>
                                        <select class="form-control custom-select d-block w-100  positionofone"
                                            id="position_id" name="position_id">
                                            <option value="0" disabled="true" selected="true">
                                                position
                                            </option>



                                        </select>
                                        <div id="detailsd" class=" font-20 ">


                                        </div>
                                        <div id="details" class=" ml-25 ">


                                        </div>
                                        <div id="details2" class=" ml-25 ">


                                        </div>
                                        <div id="details4" class=" ml-25 "></div>

                                        <div id="details3" class=" ml-25 ">


                                        </div>

                                    </div>


                                </div>
                                <button class="text-white text-left mt-3 mb-4" style=" background-color:#456896">
                                    ምርጫ 2</button>
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for=""> የስራ ክፍሉ</label>

                                        <select class="form-control custom-select d-block w-100  dynamic2"
                                            name="jobcat2_id" id="jobcat2_id">
                                            <option value="">Choose </option>
                                            <?php $__currentLoopData = $jobcat2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($col->id); ?>"
                                                    <?php echo e($form->jobcat2_id == $col->id ? 'selected' : ''); ?>>
                                                    <?php echo e($col->job_category); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-md-6 form-group">

                                        <label for="choice2_id"> የስራ መደብ</label>
                                        <select class="form-control custom-select d-block w-100  positionofone"
                                            id="choice2_id" name="choice2_id">
                                            <option value="0" disabled="true" selected="true">
                                                position
                                            </option>

                                        </select>
                                        <div id="detaild" class=" font-20 "></div>
                                        <div id="detail" class=" ml-25 ">


                                        </div>
                                        <div id="detail2" class=" ml-25 ">


                                        </div>
                                        <div id="detail4" class=" ml-25 "></div>

                                        <div id="detail3" class=" ml-25 ">


                                        </div>

                                    </div>




                                </div>






                                <button type="submit" class="btn bg-blue-dark-3 text-white float-right ">Save
                                </button>




                            </form>


                        </div>

                    </div>

                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>

    <script>
        $(document).ready(function() {

            var i = 0
            $(".addRow").click(function(e) {
                ++i;
                e.preventDefault();
                $("#myform").append(`
                        <div class="row" >
                                    <div class="col-sm">

                                            <div class=" formgr row">

                                                <div class="col-md-3">
                                       <label for="startingDate"></label>

                                                    <input type="date" name="addFields[${i}][startingDate]" value="<?php echo e(old('startingDate')); ?>"
                                                        class="form-control  <?php $__errorArgs = ['startingDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="startingDate" placeholder=" ">
                                                    <?php $__errorArgs = ['startingDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class=" error invalid-feedback">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                                <div class="col-md-3">
                                                  <label for="endingDate"></label>
                                                    <input type="date" name="addFields[${i}][endingDate]" value="<?php echo e(old('endingDate')); ?>}"
                                                        class="form-control  <?php $__errorArgs = ['endingDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="endingDate" placeholder=" endingDate">
                                                    <?php $__errorArgs = ['endingDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class=" error invalid-feedback">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-md-4">
                                                    <label for="positionyouworked"></label>

                                                    <input type="text" name="addFields[${i}][positionyouworked]" value="<?php echo e(old('positionyouworked')); ?>"
                                                        class="form-control  <?php $__errorArgs = ['positionyouworked'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="positionyouworked" placeholder="የሰሩበት የስራ መደብ">
                                                    <?php $__errorArgs = ['positionyouworked'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class=" error invalid-feedback">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                                <div>

                                                    <a href="javascript:void(0)" class="btn btn-danger  removeRow mt-20 "
                                                        style=" border-radius:50%">-</a>
                                                </div>
                                            </div>

                                        </div>
                                </div>





                    `);
            });

            $(document).on('click', '.removeRow', function(e) {

                e.preventDefault();

                let row_item = $(this).parents('.formgr');
                $(row_item).remove();
            });
            $(document).on('change', '.dynamic', function() {

                var cat_id = $(this).val();
                console.log(cat_id);
                var div = $(this).parent();


                var op = " ";

                $.ajax({
                    type: "GET",
                    url: "try/job",
                    data: {
                        "id": cat_id
                    },
                    success: function(data) {

                        op += '<option value="0" selected disabled>select</option>';
                        for (var i = 0; i < data.length; i++) {
                            op += '<option value="' + data[i].id + '">' + data[i].position +
                                '</option>';
                        }

                        $('select[name="position_id"]').html(" ");
                        $('select[name="position_id"]').append(op);
                    },
                    error: function() {

                    }
                });
            });
            $(document).on('change', '#position_id', function() {
                var selected = $(this).val();
                var a = $(this).parent();
                var di = " ";
                var div = " ";
                div21 = " ";
                var div2 = " ";
                var div3 = " ";

                $.ajax({
                    url: "try/selection",
                    type: "GET",
                    data: {
                        "id": selected
                    },
                    dataType: "json",

                    success: function(data) {

                        di += " <b>ስራዉ የሚፈልገው ዝቅተኛ መስፈርት </b>  "
                        $('#detailsd').html(" ");
                        $('#detailsd').append(di);

                        div += " <b> የስራ ልምድ (በ አመት):</b> " + data.experience
                        $('#details').html(" ");
                        $('#details').append(div);

                        div2 += "<b> የትምህርት ደረጃ:</b> " + data.edu_level

                        $('#details2').html(" ");
                        $('#details2').append(div2);
                        div21 += "<b> የትምህርት ዝግጅት:</b> " + data.education_type

                        $('#details4').html(" ");
                        $('#details4').append(div21);
                        div3 += "<b> ደረጃ:</b> " + data.level

                        $('#details3').html(" ");
                        $('#details3').append(div3);


                    },
                    error: function() {

                    }

                });




            });
            $(document).on('change', '.dynamic2', function() {


                var categ_id = $(this).val();

                console.log(categ_id);
                var div = $(this).parent();


                var op = " ";

                $.ajax({
                    type: "GET",
                    url: "try/categ2",
                    data: {
                        "id": categ_id
                    },
                    success: function(data) {

                        op += '<option value="0" selected disabled>select</option>';
                        for (var i = 0; i < data.length; i++) {
                            op += '<option value="' + data[i].id + '">' + data[i].position +
                                '</option>';
                        }

                        $('select[name="choice2_id"]').html(" ");
                        $('select[name="choice2_id"]').append(op);
                    },
                    error: function() {

                    }
                });
            });
            $(document).on('change', '#choice2_id', function() {
                var selected = $(this).val();
                var a = $(this).parent();
                var di = " ";
                var div = " ";
                var div21 = " ";
                var div2 = " ";
                var div3 = " ";

                $.ajax({
                    url: "try/selection2",
                    type: "GET",
                    data: {
                        "id": selected
                    },
                    dataType: "json",

                    success: function(data) {

                        di += " <b>ስራዉ የሚፈልገው ዝቅተኛ መስፈርት </b>  "
                        $('#detaild').html(" ");
                        $('#detaild').append(di);

                        div += "<b> የስራ ልምድ(በ አመት):</b> " + data.experience
                        $('#detail').html(" ");
                        $('#detail').append(div);

                        div2 += "<b> የትምህርት ደረጃ:</b> " + data.edu_level

                        $('#detail2').html(" ");
                        $('#detail2').append(div2);
                        div21 += "<b> የትምህርት ዝግጅት:</b> " + data.education_type

                        $('#detail4').html(" ");
                        $('#detail4').append(div21);
                        div3 += "<b> ደረጃ:</b> " + data.level

                        $('#detail3').html(" ");
                        $('#detail3').append(div3);


                    },
                    error: function() {

                    }

                });




            });






        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\placement_wolkite\resources\views/hr/show.blade.php ENDPATH**/ ?>