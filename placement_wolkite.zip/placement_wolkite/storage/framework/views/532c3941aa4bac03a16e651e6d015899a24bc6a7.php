<div class="hk-footer-wrap container">
    <footer class="footer">
        <div class="row">
            <div class="col-md-6 col-sm-12">
                <p>Developed by<a href="#" class="text-dark" target="_blank">Yonas T.(Tel:+251953464171) ,Eyob B. & Emebet T. </a> © 2023</p>
            </div>
            
        </div>
    </footer>
</div>
<?php /**PATH C:\Users\hp\placement_wolkite\resources\views/components/footer.blade.php ENDPATH**/ ?>