<?php $__env->startSection('content'); ?>
    
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <div class="container">

        <section class="hk-sec-wrapper mt-100">
            <div class="pull-right hk-sec-title">


            </div>
            <h5 class="hk-sec-title">ከቡድን መሪ በላይ ተወዳዳሪዎች 1ኛ ምርጫ በስራ አስፈጻሚ የስራ መደብ ስር</h5>


            <div class="row" id="search_list">
                <div class="col-sm">
                    <div class="table-wrap">

                        <table id="datable_3" class="table table-hover  table-bordered w-100  pb-30">
                            <thead>
                                <tr>
                                    <th>ተቁ</th>




                                    <th>የሚወዳደሩበት የስራ መደብ</th>







                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $j = 0;
                                ?>
                                <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                        <tr>
                                            <td><?php echo e(++$j); ?></td>
                                            <td>
                                                <form action="" method="POST"><a
                                                        href="<?php echo e(route('posDetailpres', $form->id)); ?>" class="mr-25"
                                                        data-toggle="tooltip"
                                                        data-original-title="show"><?php echo e($form->job_category->job_category); ?>\<?php echo e($form->position); ?>

                                                    </a>
                                                </form>
                                            </td>









                                            </td>
                                        </tr>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>



                    </div>
                </div>
            </div>
        </section>





    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\placement_wolkite\resources\views/presidential/pos.blade.php ENDPATH**/ ?>