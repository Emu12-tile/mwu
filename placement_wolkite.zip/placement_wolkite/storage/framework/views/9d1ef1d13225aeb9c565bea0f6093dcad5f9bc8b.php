<!DOCTYPE html>
<!--
Template Name: Pinkman - Responsive Bootstrap 4 Admin Dashboard Template
Author: Hencework

License: You must have a valid license purchased only from themeforest to legally use the template for your project.
-->
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>Result</title>
    <meta name="description" content="A responsive bootstrap 4 admin dashboard template by hencework" />

    <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    
    
    <!-- vector map CSS -->
    <link href="<?php echo e(asset('assets/vendors/vectormap/jquery-jvectormap-2.0.3.css')); ?>" rel="stylesheet" type="text/css" />

    <!-- Toggles CSS -->
    <link href="<?php echo e(asset('assets/vendors/jquery-toggles/css/toggles.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/vendors/jquery-toggles/css/themes/toggles-light.css')); ?>" rel="stylesheet"
        type="text/css">

    <!-- Toastr CSS -->
    <link href="<?php echo e(asset('assets/vendors/jquery-toast-plugin/dist/jquery.toast.min.css')); ?>" rel="stylesheet"
        type="text/css">
    
    <link href="<?php echo e(asset('assets/vendors/select2/dist/css/select2.min.css')); ?>" rel="stylesheet" type="text/css">


    <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" target="_blank"
        rel="nofollow" rel="stylesheet">


    <!-- Custom CSS -->
    <link href="<?php echo e(asset('assets/dist/css/style.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/vendors/datatables.net-dt/css/jquery.dataTables.min.css')); ?>" rel="stylesheet"
        type="text/css" />

    <link href="<?php echo e(asset('assets/vendors/datatables.net-responsive-dt/css/responsive.dataTables.min.css')); ?>"
        rel="stylesheet" type="text/css" />
    

    <!-- Scripts -->
    
    <style>
        /* .bodypdf {
            height: 100%;
            padding: 0;
            padding-bottom: 100px;
        } */

        .footerpdf {
            /* position: fixed;
            bottom: 0;
            height: 50px;
            width: 100%;
            background-color: #ddd;
            text-align: center; */
            /* position: fixed; */
            text-align: center;
            background-color: #ddd;
            font-size: 1em;
            width: 100%;
            /* top:1100px; */
            height: 40px;
            overflow: hidden;

            bottom: 0;
        }

        .footerpdf>p {
            margin-top: calc(20px - 0.5em);
            /* margin-bottom: calc(20px-0.5em) */
            height: auto;
        }

        /* @font-face {
            font-family: 'noto sans ethiopic', sans-serif;
            font-style: normal;
            font-weight: normal;

            src: url('https://fonts.googleapis.com/css2?family=Noto+Sans+Ethiopic&display=swap.ttf') format('truetype');
        } */
        /* @font-face {
            font-family: 'Noto Sans Ethiopic';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/notosansethiopic/v42/7cHPv50vjIepfJVOZZgcpQ5B9FBTH9KGNfhSTgtoow1KVnIvyBoMSzUMacb-T35OK5D1yGbuaQ.woff2) format('woff2');
            unicode-range: U+1200-1399, U+2D80-2DDE, U+AB01-AB2E;
        } */

      
        #customers {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #customers tr:nth-child(2) {
            /* background-color: #6d6a6a; */
        }

        /* #customers tr:nth-child(even) {
            background-color: #f2f2f2;
        } */

        #customers tr:hover {
            background-color: #ddd;
        }

        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            /* background-color: #5f5656; */
            color: rgb(29, 28, 28);
        }
    </style>


</head>

<body>
    <!-- Preloader -->
    <div class="preloader-it">
        <div class="loader-pendulums"></div>
    </div>
    <!-- /Preloader -->

    <!-- HK Wrapper -->
    <div class="hk-wrapper hk-vertical-nav">



        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <!-- /Top Navbar -->

        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidenav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidenav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


        <!-- Main Content -->
        <div class="hk-pg-wrapper">
            <!-- Container -->
            <div class="container-fluid mt-xl-50 mt-sm-30 mt-15">

                <!-- Row -->
                <main>

                    <?php echo $__env->yieldContent('content'); ?>
                    <?php echo $__env->yieldContent('layouts.navigation'); ?>


                </main>
                <!-- /Row -->
            </div>
            <!-- /Container -->

            <!-- Footer -->
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <!-- /Footer -->
        </div>
        <!-- /Main Content -->

    </div>
    <!-- /HK Wrapper -->

    <!-- jQuery -->
    <script src="<?php echo e(asset('assets/vendors/jquery/dist/jquery.min.js')); ?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(asset('assets/vendors/popper.js/dist/umd/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>

    <!-- Slimscroll JavaScript -->
    <script src="<?php echo e(asset('assets/dist/js/jquery.slimscroll.js')); ?>"></script>

    <!-- Fancy Dropdown JS -->
    <script src="<?php echo e(asset('assets/dist/js/dropdown-bootstrap-extended.js')); ?>"></script>

    <!-- FeatherIcons JavaScript -->
    <script src="<?php echo e(asset('assets/dist/js/feather.min.js')); ?>"></script>

    <!-- Toggles JavaScript -->
    <script src="<?php echo e(asset('assets/vendors/jquery-toggles/toggles.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/js/toggle-data.js')); ?>"></script>

    <!-- Counter Animation JavaScript -->
    <script src="<?php echo e(asset('assets/vendors/waypoints/lib/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/jquery.counterup/jquery.counterup.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/vendors/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/js/select2-data.js')); ?>"></script>


    <!-- Sparkline JavaScript -->
    <script src="<?php echo e(asset('assets/vendors/jquery.sparkline/dist/jquery.sparkline.min.js')); ?>"></script>

    <!-- Vector Maps JavaScript -->
    <script src="<?php echo e(asset('assets/vendors/vectormap/jquery-jvectormap-2.0.3.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/vectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/vectormap/jquery-jvectormap-de-merc.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/js/vectormap-data.js')); ?>"></script>

    <!-- Owl JavaScript -->
    <script src="<?php echo e(asset('assets/vendors/owl.carousel/dist/owl.carousel.min.js')); ?>"></script>

    <!-- Toastr JS -->
    

    <!-- Apex JavaScript -->
    <script src="<?php echo e(asset('assets/vendors/apexcharts/dist/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/js/irregular-data-series.js')); ?>"></script>

    <!-- Init JavaScript -->
    <script src="<?php echo e(asset('assets/dist/js/init.js')); ?>"></script>
    

    <script src="<?php echo e(asset('assets/vendors/editable-table/mindmup-editabletable.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/editable-table/numeric-input-example.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/js/editable-table-data.js')); ?>"></script>


    

    <script src="<?php echo e(asset('assets/vendors/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net-dt/js/dataTables.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net-buttons/js/buttons.flash.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/jszip/dist/jszip.min.js')); ?>"></script>
    
    
    <script src="<?php echo e(asset('assets/vendors/datatables.net-buttons/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/js/dataTables-data.js')); ?>"></script>
    
    <script src="<?php echo e(asset('assets/vendors/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/js/select2-data.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/vendors/tablesaw/dist/tablesaw.jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/js/tablesaw-data.js')); ?>"></script>

    
</body>

</body>
<?php echo $__env->yieldContent('javascript'); ?>


</html>
<?php /**PATH C:\Users\hp\placement_wolkite\resources\views/layouts/admin.blade.php ENDPATH**/ ?>