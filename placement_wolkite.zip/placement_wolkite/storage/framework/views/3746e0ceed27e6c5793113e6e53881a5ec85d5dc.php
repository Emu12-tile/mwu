

<?php $__env->startSection('content'); ?>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <div class="container">


        <section class="hk-sec-wrapper mt-100">
            <div class="pull-right hk-sec-title">

                
            </div>
            <h5 class="hk-sec-title">የተወዳዳሪዎች 1ኛ ምርጫ ከ ቡድን መሪ በላይ አጠቃላይ ውጤት </h5>

            <div class="row">
                <div class="col-sm">
                    <div class="table-wrap">
                        <div class="table-responsive">
                            <table id="datable_3" class="table table-hover table-bordered w-100  pb-30">
                                <thead>

                                    <tr>

                                        <th>ተ.ቁ</th>
                                        <th> ስም</th>
                                        <th> በሰው ኃብት ውጤት (65%)</th>

                                        <th> በበላይ አመራር ለአመራርነት ክህሎት የሚሠጥ ነጥብ(35%)</th>
                                        <th>አጠቃላይ ውጤት(100%)</th>
                                        

                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $hrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $hr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($hr->status == 1): ?>
                                            <tr>
                                                <td><?php echo e(++$i); ?></td>
                                                <td><?php echo e($hr->hr->form->full_name); ?> <p><?php echo e($hr->hr->form->email); ?></p>
                                                </td>



                                                <td><?php echo e($hr->hr->performance + $hr->hr->experience + $hr->hr->resultbased + $hr->hr->exam); ?>

                                                </td>
                                                <td><?php echo e($hr->presidentGrade); ?></td>
                                                <td><?php echo e($hr->hr->performance + $hr->hr->experience + $hr->hr->resultbased + $hr->hr->exam + $hr->presidentGrade); ?>

                                                </td>
                                                

                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                            

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <div class="container">


        <section class="hk-sec-wrapper mt-100">
            <div class="pull-right hk-sec-title">

                
            </div>
            <h5 class="hk-sec-title">የተወዳዳሪዎች 2ኛ ምርጫ ከ ቡድን መሪ በላይ አጠቃላይ ውጤት </h5>

            <div class="row">
                <div class="col-sm">
                    <div class="table-wrap">
                        <div class="table-responsive">
                            <table id="datable_6" class="table table-hover table-bordered w-100  pb-30">
                                <thead>



                                    <tr>

                                        <th>ተ.ቁ</th>
                                        <th> ስም</th>



                                        <th> በሰው ኃብት ውጤት (65%)</th>

                                        <th> በበላይ አመራር ለአመራርነት ክህሎት የሚሠጥ ነጥብ(35%)</th>
                                        <th>አጠቃላይ ውጤት(100%)</th>


                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $secondhrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $hr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($hr->status == 1): ?>
                                            <tr>
                                                <td><?php echo e(++$i); ?></td>
                                                <td><?php echo e($hr->secondhr->form->full_name); ?> <p>
                                                        <?php echo e($hr->secondhr->form->email); ?></p>
                                                </td>



                                                <td><?php echo e($hr->secondhr->performance + $hr->secondhr->experience + $hr->secondhr->resultbased + $hr->secondhr->exam); ?>

                                                </td>
                                                <td><?php echo e($hr->presidentGrade); ?></td>
                                                <td><?php echo e($hr->secondhr->performance + $hr->secondhr->experience + $hr->secondhr->resultbased + $hr->secondhr->exam + $hr->presidentGrade); ?>

                                                </td>


                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                            

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\placement_wolkite\resources\views/homepage/detailall.blade.php ENDPATH**/ ?>