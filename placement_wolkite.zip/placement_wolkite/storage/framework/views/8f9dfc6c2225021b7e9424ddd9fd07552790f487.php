<nav class="navbar navbar-expand-xl navbar-dark fixed-top hk-navbar" style=" background-color:#456896">
    <a id="navbar_toggle_btn" class="navbar-toggle-btn nav-link-hover" href="javascript:void(0);"><i
            class="ion ion-ios-menu"></i></a>
    <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
        
        <img class="brand-img d-inline-block " src="<?php echo e(asset('assets/dist/img/wolkite.png')); ?>"
            style="width:auto; height:100px" alt="brand" />
        

        
        
    </a>
    <ul class="navbar-nav hk-navbar-content">
        <li class="nav-item">
            
        </li>

        <li class="nav-item dropdown dropdown-authentication">
            <a class="nav-link dropdown-toggle no-caret" href="#" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <div class="media">
                    <div class="media-img-wrap">
                        <div class="avatar">
                            <img src="<?php echo e(asset('assets/dist/img/avatar12.jpg')); ?>" alt="user"
                                class="avatar-img rounded-circle">
                        </div>
                        <span class="badge badge-success badge-indicator"></span>
                    </div>
                    <div class="media-body">
                        <span> <?php echo e(Auth::user()->name); ?><i class="zmdi zmdi-chevron-down"></i></span>
                    </div>
                </div>
            </a>
            <div class="dropdown-menu dropdown-menu-right" data-dropdown-in="flipInX" data-dropdown-out="flipOutX">
                <a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>"><i
                        class="dropdown-icon zmdi zmdi-account"></i><span>Profile</span></a>

                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                              document.getElementById('logout-form').submit();">
                    <i class="dropdown-icon zmdi zmdi-power"></i><span>Log out</span>
                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>


            </div>
        </li>
    </ul>
</nav>

<?php /**PATH C:\Users\hp\placement_wolkite\resources\views/components/nav.blade.php ENDPATH**/ ?>