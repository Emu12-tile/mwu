
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <section class="hk-sec-wrapper">

                    <div class="pull-right">
                        <a class="btn btn-dark" href="<?php echo e(url('result-choice1')); ?>"> Back</a>
                    </div>



                    <h5 class="hk-sec-title"> የመመዘኛ መስፈርቶች ከቡድን መሪ በላይ
                    </h5>
                    <div class="row">

                        <div class="col-sm">

                            <div class="row">
                                <div class="col-md-6">

                                    <div class="table-wrap mb-20">
                                        <div class="table-responsive">

                                            <table class="table table-active table-bordered mb-0">
                                                <thead class="thead-active">
                                                    <tr>
                                                        <th>ተ.ቁ</th>
                                                        <th>የመመዘኛ መስፈርቶች</th>


                                                        <th>የ ማወዳደርያ ነጥብ(35%)</th>


                                                    </tr>
                                                </thead>

                                                <tbody>

                                                    <tr>
                                                        <th scope="row">1</th>
                                                        <td> በበላይ አመራር ለአመራርነት ክህሎት የሚሠጥ ነጥብ </td>
                                                        <td>

                                                            <button class="btn bg-blue-dark-4 text-white" type="button"
                                                                data-toggle="collapse" data-target="#collapseExamplepres"
                                                                aria-expanded="false" aria-controls="collapseExample">
                                                                35
                                                            </button>
                                                        </td>

                                                    </tr>



                                                </tbody>

                                            </table>

                                        </div>
                                    </div>


                                </div>






                                <div class="col-md-6 ">





                                    <div class="collapse" id="collapseExamplepres">
                                        <div class="card card-body">

                                            <div class="table-wrap mb-20 ">
                                                <div class="table-responsive">
                                                    <table class="table table-active table-bordered mb-0">
                                                        <thead class="thead-active">
                                                            <tr>
                                                                <th>ተ.ቁ</th>

                                                                <th>የማወዳደሪያ መስፈርት</th>
                                                                <th>ነጥብ
                                                                    ክብደት</th>

                                                            </tr>
                                                        </thead>

                                                        <tbody>
                                                            <tr>
                                                                <th scope="row">1</th>

                                                                <td>የመንግስትን ሀብት በቁጠባ መጠቀም፣ ታማኝነትና ቅንነት

                                                                    መላበስ</td>
                                                                <td>
                                                                    5
                                                                </td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">2</th>
                                                                <td>በወቅቱ ተገቢነት ያለው ውሳኔ መስጠት </td>
                                                                <td>5</td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">3</th>
                                                                <td>የሴክተሩን ፖሊሲ፣ ስትራቴጂና ፕሮግራሞችን ከተቋሙ ራእይና
                                                                    ተልእኮ ጋር በማቀናጀት ለስኬት የራሱን ድርሻ ለመወጣት በቂግንዛቤ የያዘና ሌላውን
                                                                    ለማስገንዘብ
                                                                    የሚተጋ </td>
                                                                <td>5</td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">4</th>
                                                                <td>ተጨማሪ ተልእኮ ወስዶ የመፈፀምና በወቅቱ የማቅረብ ብቃት፣

                                                                    ቁርጠኝነትና ከፍተኛ የተነሳሽነት ስሜት መኖር

                                                                </td>
                                                                <td>5</td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">5</th>
                                                                <td>የአመራር ብቃት ፣ የተግባቦት ብቃት ፣ የዕቅድ ዝግጅት ጥራት
                                                                    ፣የሪፖርት ዝግጀት ጥራት፣፤ በውስጡ ያሉ ሰራተኞችን

                                                                    የመምራት ብቃት፣ ሁልጊዜ ከሰራተኞች ጋር አብሮ የመስራት</td>
                                                                <td>5</td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">6</th>
                                                                <td> የኢንፎርሜሽን ኮሙኒኬሽን ቴከኖሎጂን በብቃት ለስራ ።

                                                                    መጠቀም </td>
                                                                <td>5</td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">7</th>
                                                                <td> ለማህደር ጥራት የሚሰጥ ነጥብ</td>
                                                                <td>5</td>

                                                            </tr>

                                                        </tbody>

                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>














                                </div>
                            </div>

                            <form action="<?php echo e(route('addPresidentPost', $id)); ?>" method="POST" id="add_evaluation">
                                <?php echo csrf_field(); ?>

                                <div class="row">
                                    


                                    <div class="col-sm">
                                        <div class="table-wrap">
                                            <div class="table-responsive">
                                                <table class="table table-sm table-bordered mb-0">
                                                    <thead class="thead-active">
                                                        <tr>

                                                            <th>ሙሉ ስም</th>
                                                            <th>ጾታ</th>
                                                            <th>የሚወዳደሩበት የስራ መደብ</th>
                                                            <th>አሁን ያሉበት የትምህርት ደረጃና ዝግጅት</th>

                                                            <th> የስራ ልምድዎ </th>
                                                            <th>የሁለት ተከታታይ የስራ አፈጻጸም አማካይ ውጤት</th>
                                                            <th>ተጨማሪ ይመልከቱ</th>




                                                        </tr>
                                                    </thead>
                                                    <tbody>

                                                        <tr>

                                                            <td><?php echo e($form->form->full_name); ?>

                                                            </td>
                                                            <td><?php echo e($form->form->sex); ?></td>
                                                            <td><?php echo e($form->form->position->position); ?></td>

                                                            <td>
                                                                <?php $__currentLoopData = $edu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    (<?php echo e($type->level); ?>,
                                                                    <?php echo e($type->discipline); ?>,<?php echo e($type->completion_date); ?>)
                                                                    ,
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </td>




                                                            <td>
                                                                <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php

                                                                    $fdate = Carbon::parse($fo->startingDate);

                                                                    $tdate = Carbon::parse($fo->endingDate);

                                                                    // $years = $tdate - $fdate;
                                                                    $days = $tdate->diffInDays($fdate);
                                                                    $months = $tdate->diffInMonths($fdate);

                                                                    $years = $tdate->diffInYears($fdate);
                                                                    // dd($fdate->diffForHumans($tdate));
                                                                    // dd($years,$months,$days);

                                                                    $time = $tdate->diff($fdate);
                                                                    // echo $time->y;

                                                                    echo $time->y, 'ዓመት', 'ከ', $time->m, ' ወር በ(', $fo->positionyouworked, '), ';

                                                                    ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </td>
                                                            <td><?php echo e($form->form->resultOfrecentPerform); ?>

                                                            </td>
                                                            <td data-toggle="collapse" data-target="#more"
                                                                aria-expanded="false" aria-controls="collapseExample">more
                                                                <i class='ion ion-md-arrow-round-forward'></i>


                                                            </td>




                                                        </tr>

                                                    </tbody>
                                                </table>
                                                

                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="collapse" id="more">
                                    <div class="card card-body">

                                        <div class="table-wrap mb-20 ">
                                            <div class="table-responsive">
                                                <table class="table table-active table-bordered mb-0">
                                                    <thead class="thead-active">
                                                        <tr>


                                                            <th>አሁን ያሉበት የስራ መደብ</th>
                                                            <th>ደረጃ</th>
                                                            <th>ደምወዝ</th>
                                                            <th>በዩኒቨርስቲዉ የቅጥር ዘመን
                                                                በኢትዮጵያ</th>
                                                            <th>በዩኒቨርስቲዉ አገልግሎት ዘመን
                                                                (በዓመት,የስራ
                                                                መደብ)</th>
                                                            <th>በሌላ መስርያ ቤት አገልግሎት
                                                                ዘመን(በዓመት,የስራ
                                                                መደብ)</th>
                                                            <th>አገልግሎት ከዲፕሎማ
                                                                በፊት(በዓመት,የስራ መደብ)</th>
                                                            <th>አገልግሎት ከዲፕሎማ/ዲግሪ
                                                                በኋላ(በዓመት, የስራ መደብ)</th>
                                                            <th>የዲስፕሊን ጉድለት</th>
                                                            <th>ተጨማሪ የሥራ ድርሻ</th>

                                                        </tr>
                                                    </thead>

                                                    <tbody>
                                                        <tr>

                                                            <td><?php echo e($form->form->positionofnow); ?></td>
                                                            <td><?php echo e($form->form->level); ?></td>
                                                            <td><?php echo e($form->form->fee); ?></td>
                                                            <td><?php echo e($form->form->UniversityHiringEra); ?></td>
                                                            <td><?php echo e($form->form->servicPeriodAtUniversity); ?></td>
                                                            <td><?php echo e($form->form->servicPeriodAtAnotherPlace); ?></td>
                                                            <td><?php echo e($form->form->serviceBeforeDiplo); ?></td>
                                                            <td><?php echo e($form->form->serviceAfterDiplo); ?></td>
                                                            <td><?php echo e($form->form->DisciplineFlaw); ?></td>
                                                            <td><?php echo e($form->form->MoreRoles); ?></td>
                                                        </tr>

                                                    </tbody>

                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-40">

                                    <div class="col-md-6 form-group">
                                        <label for="firstName">በበላይ ሃላፊ ለአመራርነት ክህሎት የሚሰጥ ነጥብ ከ(35%) </label>
                                        <input class="form-control <?php $__errorArgs = ['presidentGrade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="firstName" placeholder="ለአመራርነት ክህሎት  ከ(35%)"
                                            value="<?php echo e(old('presidentGrade')); ?>" type="float" name="presidentGrade"
                                            min="0" max="35">
                                        <?php $__errorArgs = ['presidentGrade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class=" error invalid-feedback">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="exam">Remark</label>
                                        <textarea class="form-control <?php $__errorArgs = ['remark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="remark" placeholder="remark"
                                            value="<?php echo e(old('remark')); ?>" type="text" name="remark"></textarea>
                                        <?php $__errorArgs = ['remark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class=" error invalid-feedback">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>







                                </div>
                                <div class="form-group row mb-0 pull-right">
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn bg-blue-dark-4 text-white"
                                            id="add_btn">save</button>
                                    </div>
                                </div>





                            </form>


                        </div>

                    </div>
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\placement_wolkite\resources\views/presidential/evaluate.blade.php ENDPATH**/ ?>