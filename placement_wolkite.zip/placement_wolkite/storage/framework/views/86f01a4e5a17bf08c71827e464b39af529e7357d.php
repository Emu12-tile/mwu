<!DOCTYPE html>
<!--
Template Name: Pinkman - Responsive Bootstrap 4 Admin Dashboard Template
Author: Hencework

License: You must have a valid license purchased only from themeforest to legally use the template for your project.
-->
<html lang="en">

<head>
    <style>
        /* @font-face {
            font-family: 'iskpota';
            src: url('<?php echo e(public_path()); ?>/fonts/your-font.ttf') format('truetype')
        }

        body {
            font-family: 'your-font', sans-serif;
        } */
    </style>
    
    
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Wolkite</title>
    <meta name="description" content="A responsive bootstrap 4 admin dashboard template by hencework" />

    <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="icon" href="favicon.ico" type="image/x-icon">

    <!-- Lightgallery CSS -->
    <link href="<?php echo e(asset('assets/dist/css/lightgallery.css')); ?>" rel="stylesheet" type="text/css">

    <!-- Custom CSS -->
    
    <link href="<?php echo e(asset('assets/dist/css/style.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/src/scss/style.scss')); ?>" rel="stylesheet" type="text/scss">


</head>

<body data-spy="scroll" data-target=".navbar" data-offset="60">
    <!-- Preloader -->
    
    <!-- /Preloader -->

    <!-- HK Wrapper -->


    <div class="hk-wrapper hk-alt-nav hk-landing">
        
        
        <div class="fixed-top  shadow-sm " style=" background-color:#456896">
            <div class="container px-0">
                
                <nav class="navbar navbar-expand-xl navbar-light  hk-navbar hk-navbar-alt shadow-none"
                    style=" background-color:#456896">
                    <a class="navbar-toggle-btn nav-link-hover navbar-toggler" href="javascript:void(0);"
                        data-toggle="collapse" data-target="#navbarCollapseAlt" aria-controls="navbarCollapseAlt"
                        aria-expanded="false" aria-label="Toggle navigation"><span class="feather-icon"><i
                                data-feather="menu"></i></span></a>
                    <a class="navbar-brand" href="">
                        <img class="brand-img d-inline-block align-top "
                            src="<?php echo e(asset('assets/dist/img/wolkite.png')); ?>" style="width:auto; height:100px"
                            alt="brand" />
                    </a>
                    

                    <div class="collapse navbar-collapse ml-auto" id="navbarCollapseAlt">
                        <ul class="navbar-nav ml-auto">

                            <li class="nav-item">
                                <a class="nav-link text-white" data-scroll href="<?php echo e(route('login')); ?>">Login </a>

                                
                            </li>
                            
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <?php echo $__env->yieldContent('content'); ?>

        <div class="hk-footer-wrap container">
            <footer class="footer">
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <p>Developed by<a href="" class="text-dark" target="_blank">Yonas T.(Tel:+251953464171)
                                ,Eyob B. & Emebet
                                T.</a> ©
                            2023</p>
                    </div>
                    
                </div>
            </footer>
        </div>
        <!-- /Footer -->

    </div>
    <!-- /Main Content -->


    <!-- /Main Content -->

    </div>
    <!-- /HK Wrapper -->

    <!-- jQuery -->
    <script src="<?php echo e(asset('vendors/jquery/dist/jquery.min.js')); ?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(asset('assets/vendors/popper.js/dist/umd/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>

    <!-- Owl JavaScript -->
    <script src="<?php echo e(asset('assets/vendors/owl.carousel/dist/owl.carousel.min.js')); ?>"></script>

    <!-- FeatherIcons JavaScript -->
    <script src="<?php echo e(asset('assets/dist/js/feather.min.js')); ?>"></script>

    <!-- Gallery JavaScript -->
    <script src="<?php echo e(asset('assets/vendors/lightgallery/dist/js/lightgallery-all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/js/froogaloop2.min.js')); ?>"></script>

    <!-- Init JavaScript -->
    <script src="<?php echo e(asset('assets/dist/js/lightgallery-all.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/js/landing-data.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/js/init.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js')); ?>"></script>
    
    


    <style>
        .form-section {
            display: none;
        }

        .form-section.current {
            display: inline;
        }

        .parsley-errors-list {
            color: red;
            border-color: red;

        }

        .hide {
            display: none;
        }

        .myDIV:hover+.hide {
            display: block;
            color: red;
        }
    </style>

    
</body>
<?php echo $__env->yieldContent('javascript'); ?>

</html>
<?php /**PATH C:\Users\hp\placement_wolkite\resources\views/app.blade.php ENDPATH**/ ?>