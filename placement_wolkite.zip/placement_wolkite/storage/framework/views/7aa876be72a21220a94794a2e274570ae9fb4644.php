<!DOCTYPE html>
<html lang="en">

<head>


    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />



    <title>Document</title>
    <style>
        /* @font-face {
            font-family: 'noto sans ethiopic', sans-serif;
            font-style: normal;
            font-weight: normal;

            src: url('https://fonts.googleapis.com/css2?family=Noto+Sans+Ethiopic&display=swap.ttf') format('truetype');
        } */
        /* @font-face {
            font-family: 'Noto Sans Ethiopic';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/notosansethiopic/v42/7cHPv50vjIepfJVOZZgcpQ5B9FBTH9KGNfhSTgtoow1KVnIvyBoMSzUMacb-T35OK5D1yGbuaQ.woff2) format('woff2');
            unicode-range: U+1200-1399, U+2D80-2DDE, U+AB01-AB2E;
        } */


        #customers {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #customers tr:nth-child(2) {
            /* background-color: #6d6a6a; */
        }

        /* #customers tr:nth-child(even) {
            background-color: #f2f2f2;
        } */

        #customers tr:hover {
            background-color: #ddd;
        }

        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            /* background-color: #5f5656; */
            color: rgb(29, 28, 28);
        }
    </style>
</head>

<body>

    <div id="element-to-print">
        
        <h1 style="font-family: Noto Sans Ethiopic, sans-serif; text-align:center ">ወልቂጤ ዩኒቨርሲቲ </h1>
        <h3 style="text-align:center">የአስተዳደር ሠራተኞች ፕሮፋይል</h3>
        <p>1/ የሠራተኛው ሙሉ ስም:-<?php echo e($form->firstName); ?> <?php echo e($form->middleName); ?> <?php echo e($form->lastName); ?> </p>
        
        <p>2/ አሁን ያሉበት የስራ መደብ መጠርያ:-<?php echo e($form->positionofnow); ?> &emsp;
            ደረጃ፦<?php echo e($form->level); ?> &emsp; ደምወዝ:-<?php echo e($form->fee); ?>

        </p>
        <p>3/ የተማሩት የት/ት ዝግጅትና የት/ት ደረጃ:-
        </p>
        <table id="customers" class="mb-15">
            <thead>
                <tr>

                    <th>የትምህርት ደረጃ</th>
                    <th>የትምህርት ዝግጅት</th>
                    <th>የጨረሱበት ዓመት</th>




                </tr>



            </thead>
            <tbody>
                <?php $__currentLoopData = $form->education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $fo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td> <?php echo e($fo->level ?? ''); ?></td>
                        <td> <?php echo e($fo->discipline ?? ''); ?></td>
                        <td><?php echo e($fo->completion_date ?? ''); ?> </td>
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <p>4/ በዩኒቨርስቲዉ የቅጥር
            ዘመን በኢትዮጵያ አቆጣጠር:-
            <?php echo e($form->UniversityHiringEra); ?>


        </p>
        
        
        <h5>5/ የሚወዳደሩበት የስራ ክፍልና የስራ መደብ</h5>
        <p> ምርጫ 1</p>

        <p> የስራ ክፍል :-<?php echo e($form->job_category->job_category ?? ''); ?></p>
        <p> የስራ መደብ፣ <?php echo e($form->position->position ?? ''); ?></p>
        <p>
            ምርጫ 2</p>
        <p> የስራ ክፍል:- <?php echo e($form->jobcat2->job_category ?? ''); ?> </p>
        <p> የስራ መደብ:- <?php echo e($form->choice2->position ?? ''); ?></p>
        <div class="html2pdf__page-break"></div>
        <p>6/ ጠቅላላ የስራ ልምድ ብዛትና የስራው አይነት</p>

        <table id="customers">
            <thead>
                <tr>
                    <th rowspan="2">ተ.ቁ</th>
                    <th rowspan="2">የአገልግሎት ዘመን ከ---እስከ---ዓ.ም</th>
                    <th rowspan="2">የሥራ ዓይነት</th>

                    <th colspan="3"> የአገልግሎት ጊዜ</th>
                    <th rowspan="2">ምርመራ</th>


                </tr>
                <tr>

                    <th>ዓመት</td>
                    <th>ወር</td>
                    <th>ቀን</td>
                </tr>

            </thead>
            <tbody>
                <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $fo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$i); ?></td>
                        
                        <td>
                            
                            
                            


                            ከ<?php echo e(Carbon::parse($fo->startingDate)->day); ?>/<?php echo e(Carbon::parse($fo->startingDate)->month); ?>/<?php echo e(Carbon::parse($fo->startingDate)->year); ?>

                            እስከ
                            <?php echo e(Carbon::parse($fo->endingDate)->day); ?>/<?php echo e(Carbon::parse($fo->endingDate)->month); ?>/<?php echo e(Carbon::parse($fo->endingDate)->year); ?>

                        </td>
                        </td>
                        <td><?php echo e($fo->positionyouworked); ?></td>
                        <td>
                            <?php

                            $fdate = Carbon::parse($fo->startingDate);

                            $tdate = Carbon::parse($fo->endingDate);

                            // $years = $tdate - $fdate;

                            // echo abs($years);
                            //

                            $days = $tdate->diffInDays($fdate);
                            $months = $tdate->diffInMonths($fdate);

                            $years = $tdate->diffInYears($fdate);
                            // dd($fdate->diffForHumans($tdate));
                            // dd($years,$months,$days);

                            $time = $tdate->diff($fdate);
                            echo $time->y;
                            //   {{$time->y}} year, {{$time->m}} months, {{$time->d}} days
                            // dd($time->y);
                            ?>
                        </td>
                        <td>
                            <?php

                            $fdate = Carbon::parse($fo->startingDate);

                            $tdate = Carbon::parse($fo->endingDate);

                            // $months = $tdate - $fdate;

                            //   echo abs($months);
                            $time = $tdate->diff($fdate);
                            echo $time->m;
                            ?>
                        </td>
                        <td>
                            <?php

                            // $fdate = Carbon::parse($fo->startingDate);

                            // $tdate = Carbon::parse($fo->endingDate);
                            $time = $tdate->diff($fdate);
                            // $days = $tdate - $fdate;
                            echo $time->d;
                            // echo abs($days);
                            ?>
                        </td>
                        <td></td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="html2pdf__page-break"></div>
        
        <p>7/ የሁለት ተከታታይ የቅርብ ጊዜ የሥራ አፈጻፀም አማካይ ውጤት:-<?php echo e($form->resultOfrecentPerform); ?></p>
        <p>8/ የዲስፕሊን ጉድለት:-<?php echo e($form->DisciplineFlaw); ?></p>
        
        <p>ቅጹን የሞላው ሰራተኛ ስም
            &mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;
            ፊርማ&mdash;&mdash;&mdash;&mdash; ቀን&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;</p>
        <p>ስለትክክለኛነቱ ያረጋገጠው የሰዉ ሀብት ባለሙያ ፊርማ&mdash;&mdash;&mdash;&mdash;&mdash;
            ቀን&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;
        </p>

    </div>


</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.8.0/html2pdf.bundle.min.js"
    integrity="sha512-w3u9q/DeneCSwUDjhiMNibTRh/1i/gScBVp2imNVAMCt6cUHIw6xzhzcPFIaL3Q1EbI2l+nu17q2aLJJLo4ZYg=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>
    var element = document.getElementById("element-to-print")


    html2pdf(element, {
        margin: 15,
        filename: 'Application form.pdf',
        image: {
            type: 'jpeg',
            quality: 0.98
        },
        html2canvas: {
            scale: 3,
            logging: true,
            dpi: 192,
            letterRendering: true
        },
        jsPDF: {
            unit: 'mm',
            format: 'a4',
            orientation: 'portrait'
        }
    })
    setTimeout(function() {
        window.location.href = "<?php echo e(url('/hr')); ?>";
    }, 5000);
</script>

</html>
<?php /**PATH C:\Users\hp\placement_wolkite\resources\views/homepage/export.blade.php ENDPATH**/ ?>