<?php $__env->startSection('content'); ?>
    <div class="hk-pg-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">

                    <section class="hk-sec-wrapper mt-100">
                        



                        <h3 class="hk-sec-title text-white text-center color-wrap  "
                            style=" background-color:#456896; padding:10px;">ወልቂጤ ዩኒቨርሲቲ የሰራተኞች የስራ
                            ድልድል ማወዳደርያ ቅፅ</h3>
                        
                    </section>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\placement_wolkite\resources\views/try.blade.php ENDPATH**/ ?>